package com.projetoA3.Versao_Final_Projeto_.A3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VersaoFinalProjetoA3Application {

	public static void main(String[] args) {
		SpringApplication.run(VersaoFinalProjetoA3Application.class, args);
	}

}
