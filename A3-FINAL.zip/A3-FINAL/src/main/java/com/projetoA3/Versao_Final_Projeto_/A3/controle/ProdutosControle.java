package com.projetoA3.Versao_Final_Projeto_.A3.controle;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.projetoA3.Versao_Final_Projeto_.A3.excecao.ProdutoNotFoundException;
import com.projetoA3.Versao_Final_Projeto_.A3.modelo.Concessionaria;
import com.projetoA3.Versao_Final_Projeto_.A3.modelo.Produtos;
import com.projetoA3.Versao_Final_Projeto_.A3.servico.ConcessionariaServico;
import com.projetoA3.Versao_Final_Projeto_.A3.servico.ProdutosServico;

import jakarta.validation.Valid;

@Controller
public class ProdutosControle {

    @Autowired
    private ProdutosServico produtosServico;

    @Autowired
    private ConcessionariaServico concessionariaServico;

@GetMapping("/novo")
    public String novoProduto(Model model){
        Produtos produtos = new Produtos();
        model.addAttribute("novoProduto", produtos);

        List<Concessionaria> concessionarias = concessionariaServico.listar();
        model.addAttribute("concessionarias", concessionarias);

        return "/novo-produto";
    }



    @PostMapping("/gravar")
    public String criarProdutos(@ModelAttribute ("novoProduto") @Valid Produtos produtos, 
        BindingResult erros, 
        RedirectAttributes attributes, Model model){
            if (erros.hasErrors()){
                List<Concessionaria> concessionarias = concessionariaServico.listar();
        model.addAttribute("concessionarias", concessionarias);
                return "/novo-produto";
            }
            produtosServico.cadastrar(produtos);
            attributes.addFlashAttribute("mensagem", "Produto salvo com sucesso!");
        return "redirect:/novo";
    }


    @GetMapping("/listar")
    public String buscarTodosProdutos(Model model){
        List<Produtos> produtos = produtosServico.buscarTodosProdutos();
        model.addAttribute("buscarProdutos", produtos);
        return "/listar-produtos";
    }

    @GetMapping("/apagarProdutos/{id}")
    public String apagarProduto(@PathVariable("id") Long id, RedirectAttributes attribute){
        try {
            produtosServico.apagarProduto(id);
        }catch (ProdutoNotFoundException e){
            attribute.addFlashAttribute("mensagemErro", e.getMessage());
        }
                return "redirect:/listar";
        
        
        
       
    }

    @GetMapping("/mudar/{id}")
    public String editarProduto(@PathVariable("id") Long id, RedirectAttributes attribute, Model model){
        try {
            Produtos produtos = produtosServico.buscarProdutosPorId(id);
            model.addAttribute("editarProdutos", produtos);
            List<Concessionaria> concessionarias = concessionariaServico.listar();
            model.addAttribute("concessionarias", concessionarias);
            return "/alterar-produto";
        }catch (ProdutoNotFoundException e){
            attribute.addFlashAttribute("mensagemErro", e.getMessage());
        }
                return "redirect:/listar";
        }
                
        
        @PostMapping("/mudar/{id}")
        public String editarProdutos(@PathVariable("id") Long id, @ModelAttribute("editarProdutos") @Valid Produtos produtos, BindingResult erros, Model model){
            if (erros.hasErrors()){
                produtos.setId(id);
                List<Concessionaria> concessionarias = concessionariaServico.listar();
            model.addAttribute("concessionarias", concessionarias);
                return "/alterar-produtos";
        }
        produtosServico.editarProduto(produtos);
                return "redirect:/listar";
                
                
        }

         @PostMapping("/find")
    public String buscarProduto(Model model, @Param("modelo") String modelo) {	
		if (modelo == null) {
			return "redirect:/listar";
		}

		List<Produtos> produtos = produtosServico.buscarTodosProdutosPorModelo(modelo);
		model.addAttribute("buscarProdutos", produtos);
		return "/listar-produtos";
    }

    }
