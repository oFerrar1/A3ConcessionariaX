package com.projetoA3.Versao_Final_Projeto_.A3.excecao;

public class ProdutoNotFoundException extends Exception{

    public ProdutoNotFoundException(String message) {
        super(message);
    }

    

}
