package com.projetoA3.Versao_Final_Projeto_.A3.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.projetoA3.Versao_Final_Projeto_.A3.modelo.Concessionaria;

@EnableJpaRepositories
public interface ConcessionariaRepositorio extends JpaRepository<Concessionaria, Long>{
    List<Concessionaria> findByNomeContainingIgnoreCase(String nome);
}
