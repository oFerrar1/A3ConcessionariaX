package com.projetoA3.Versao_Final_Projeto_.A3.servico;


import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.projetoA3.Versao_Final_Projeto_.A3.modelo.Concessionaria;
import com.projetoA3.Versao_Final_Projeto_.A3.repositorio.ConcessionariaRepositorio;

@ExtendWith(MockitoExtension.class)
public class ConcessionariaServicoTest {

    Concessionaria concessionaria = new Concessionaria();

    @Captor
    ArgumentCaptor<Concessionaria> concessionariaCaptor;

    Optional<Concessionaria> optionalConcessionaria;

    @InjectMocks
    ConcessionariaServico concessionariaServico;

    @Mock
    ConcessionariaRepositorio concessionariaRepositorio;



 

    @Test
    public void deveApagarConcessionaria() {

          //Organizar
          Concessionaria concessionaria = new Concessionaria();

         concessionaria.setEndereco("Rua 1234");
         concessionaria.setEstado("São Paulo");
          concessionaria.setNome("Matriz 1");
          concessionaria.setPais("Brasil");
         concessionaria.setId(1L);
 
         
         //Agir
         concessionariaRepositorio.deleteById(concessionaria.getId());
 
         Assertions.assertThat(concessionaria).isNull();

    }

    @Test
    public void deveBuscarConcessionariaPorId() {

        Concessionaria concessionaria = new Concessionaria();

        concessionaria.setEndereco("Rua 1234");
        concessionaria.setEstado("São Paulo");
        concessionaria.setNome("Matriz 1");
        concessionaria.setPais("Brasil");
        concessionaria.setId(1L);

        concessionariaServico.criarConcessionaria(concessionaria);
        Mockito.verify(concessionariaRepositorio).save(concessionaria);
        
        
        Mockito.when(concessionariaRepositorio.findById(Mockito.anyLong())).thenReturn(optionalConcessionaria);
    
            Assertions.assertThat(optionalConcessionaria).isNotNull();

    }



    @Test
    public void deveCriarConcessionaria() {

        //Organizar
        Concessionaria concessionaria = new Concessionaria();

        concessionaria.setEndereco("Rua 1234");
        concessionaria.setEstado("São Paulo");
        concessionaria.setNome("Matriz 1");
        concessionaria.setPais("Brasil");
        concessionaria.setId(1L);

        //Agir
        concessionariaServico.criarConcessionaria(concessionaria);
        Mockito.verify(concessionariaRepositorio).save(concessionariaCaptor.capture());
        
        //Analisar
        Concessionaria concessionariaSalva = concessionariaCaptor.getValue();

        Assertions.assertThat(concessionariaSalva.getId()).isNotNull();

    }

    @Test
    public void deveListarConcessionaria() {

        //Organizar
        Concessionaria concessionaria = new Concessionaria();

        concessionaria.setEndereco("Rua 1234");
        concessionaria.setEstado("São Paulo");
        concessionaria.setNome("Matriz 1");
        concessionaria.setPais("Brasil");
        concessionaria.setId(1L);

        //Agir
        
        Mockito.verify(concessionariaRepositorio).findAll();       
        Assertions.assertThat(concessionaria).isNotNull();


    }
}
