package com.projetoA3.Versao_Final_Projeto_.A3.servico;

import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.projetoA3.Versao_Final_Projeto_.A3.modelo.Produtos;
import com.projetoA3.Versao_Final_Projeto_.A3.repositorio.ProdutosRepositorio;

public class ProdutosServicoTest {

    
    
        private Produtos produtos = new Produtos();
    
        @InjectMocks
        private ProdutosServico produtosServico;
    
        @Mock
        private ProdutosRepositorio produtosRepositorio;
    
        Optional<Produtos> optionalProdutos;
    
        @Captor
        ArgumentCaptor<Produtos> produtosCaptor;
    
        @Test
        void deveApagarProduto() {
    
        }
    
        @Test
        void deveBuscarProdutosPorId() {
    
            Produtos produtos = new Produtos();
            produtos.setId(1L);
            produtos.setMarca("BMW");
            produtos.setPlaca("XXX-YYYY");
            produtos.setModelo("X1");
            produtos.setCor("Prata");
    
            Mockito.when(produtosRepositorio.findById(Mockito.anyLong())).thenReturn(optionalProdutos);
    
            Assertions.assertThat(optionalProdutos).isNotNull();
    }

    @Test
    void deveBuscarTodosProdutos() {

        Produtos produtos = new Produtos();
            produtos.setId(1L);
            produtos.setMarca("BMW");
            produtos.setPlaca("XXX-YYYY");
            produtos.setModelo("X1");
            produtos.setCor("Prata");
    
            Mockito.when(produtosRepositorio.findAll()).thenReturn((List<Produtos>) produtos);
    
            Assertions.assertThat(produtos).isNotNull();
    }

    

     @Test
    void deveCadastrarProdutos() {
         Produtos produtos = new Produtos();

        produtos.setCor("Prata");
        produtos.setId(1L);
         produtos.setMarca("BMW");
         produtos.setPlaca("XXX-YYYY");
         produtos.setModelo("X1");

         //Agir
       produtosServico.cadastrar(produtos);
        Mockito.verify(produtosRepositorio).save(produtos);
        
        // //Analisar
       Produtos produtosSalvo = produtosCaptor.getValue();

        Assertions.assertThat(produtos.getId()).isNotNull();

    }

   
}
