package com.projetoA3.Versao_Final_Projeto_.A3.controle;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.projetoA3.Versao_Final_Projeto_.A3.excecao.ConcessionariaNotFoundException;
import com.projetoA3.Versao_Final_Projeto_.A3.modelo.Concessionaria;
import com.projetoA3.Versao_Final_Projeto_.A3.servico.ConcessionariaServico;

import jakarta.validation.Valid;

@Controller
public class ConcessionariaControle {

    @Autowired
private ConcessionariaServico concessionariaServico;

    @GetMapping("/")
    public String listarConcessionarias(Model model){
        List<Concessionaria> concessionarias = concessionariaServico.buscarTodasConcessionarias();
        model.addAttribute("listarConcessionarias", concessionarias);
        return "/listar-concessionarias";
    }

    @GetMapping("/nova")
    public String novaConcessionaria(Model model){
        Concessionaria concessionaria = new Concessionaria();
        model.addAttribute("novaConcessionaria", concessionaria);
        return "/nova-concessionaria";
    }

    @PostMapping("/buscar")
    public String buscarConcessionaria(Model model, @Param("nome") String nome) {	
		if (nome == null) {
			return "redirect:/";
		}
		List<Concessionaria> concessionarias = concessionariaServico.buscarTodasConcessionariasPorNome(nome);
		model.addAttribute("listarConcessionarias", concessionarias);
		return "/listar-concessionarias";
    }


    @PostMapping("/cadastrar")
    public String cadastrarConcessionaria(@ModelAttribute ("novaConcessionaria") @Valid Concessionaria concessionaria, 
        BindingResult erros, 
        RedirectAttributes attributes){
            if (erros.hasErrors()){
                return "/nova-concessionaria";
            }
        concessionariaServico.criarConcessionaria(concessionaria);
            attributes.addFlashAttribute("mensagem", "Concessionaria salva com sucesso!");
        return "redirect:/nova";
    }

    @GetMapping("/apagar/{id}")
    public String apagarConcessionarias(@PathVariable ("id") Long id, RedirectAttributes attributes){
        try {
            concessionariaServico.apagarConcessionaria(id);
        } catch (ConcessionariaNotFoundException e) {
            attributes.addFlashAttribute("mensagemErro", e.getMessage());
            
        }
        return "redirect:/";
}

@GetMapping("/editar/{id}")
    public String editarFormulario(@PathVariable("id") long id, RedirectAttributes attributes,
    		Model model) {	
		try {
			Concessionaria concessionaria = concessionariaServico.buscarConcessionariaPorId(id);
			model.addAttribute("objetoConcessionaria", concessionaria);
            return "/alterar-concessionaria";
		} catch (ConcessionariaNotFoundException e) {
			attributes.addFlashAttribute("mensagemErro", e.getMessage());
		}
        return "redirect:/";
    }

    @PostMapping("/editar/{id}")
	public String editarFormulario(@PathVariable("id") long id, 
								@ModelAttribute("objetoConcessionaria") @Valid Concessionaria concessionaria, 
								BindingResult erros) {
		if (erros.hasErrors()) {
			concessionaria.setId(id);
	        return "/alterar-concessionaria";
	    }
		concessionariaServico.alterarConcessionaria(concessionaria);
		return "redirect:/";
	}


}
