package com.projetoA3.Versao_Final_Projeto_.A3.excecao;

public class ConcessionariaNotFoundException extends Exception{

    public ConcessionariaNotFoundException(String message) {
        super(message);
    }

    

}
