package com.projetoA3.Versao_Final_Projeto_.A3.servico;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.projetoA3.Versao_Final_Projeto_.A3.excecao.ConcessionariaNotFoundException;
import com.projetoA3.Versao_Final_Projeto_.A3.modelo.Concessionaria;
import com.projetoA3.Versao_Final_Projeto_.A3.repositorio.ConcessionariaRepositorio;

@Service
public class ConcessionariaServico {

    @Autowired
    private ConcessionariaRepositorio concessionariaRepositorio;

    public Concessionaria criarConcessionaria(Concessionaria concessionaria){
        return concessionariaRepositorio.save(concessionaria);
    }

    public List<Concessionaria> buscarTodasConcessionarias(){
        return concessionariaRepositorio.findAll();
    }

    public Concessionaria buscarConcessionariaPorId(Long id) throws ConcessionariaNotFoundException{
		Optional<Concessionaria> opt = concessionariaRepositorio.findById(id);
		if (opt.isPresent()) {
			return opt.get();
		} else {
			throw new ConcessionariaNotFoundException("Concessionaria com id: " +id+ "não encontrada");
		}		

}

    public void apagarConcessionaria(Long id) throws ConcessionariaNotFoundException{
        Concessionaria concessionaria = buscarConcessionariaPorId(id);
        concessionariaRepositorio.delete(concessionaria);
}

public Concessionaria alterarConcessionaria(Concessionaria concessionaria) {
    return concessionariaRepositorio.save(concessionaria);
}

public List<Concessionaria> buscarTodasConcessionariasPorNome(String nome){
    return concessionariaRepositorio.findByNomeContainingIgnoreCase(nome);

}

public List<Concessionaria> listar(){
    return concessionariaRepositorio.findAll();
}
}
