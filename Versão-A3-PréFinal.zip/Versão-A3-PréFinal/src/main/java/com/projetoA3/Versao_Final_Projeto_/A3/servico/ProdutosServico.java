package com.projetoA3.Versao_Final_Projeto_.A3.servico;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.projetoA3.Versao_Final_Projeto_.A3.excecao.ProdutoNotFoundException;
import com.projetoA3.Versao_Final_Projeto_.A3.modelo.Produtos;
import com.projetoA3.Versao_Final_Projeto_.A3.repositorio.ProdutosRepositorio;



@Service
public class ProdutosServico {

    @Autowired
    private ProdutosRepositorio produtosRepositorio;

    public Produtos cadastrar (Produtos produtos){
       return produtosRepositorio.save(produtos);
    }

    public List<Produtos> buscarTodosProdutos(){
        return produtosRepositorio.findAll();
    }

    public Produtos buscarProdutosPorId(Long id) throws ProdutoNotFoundException{
		Optional<Produtos> opt = produtosRepositorio.findById(id);
		if (opt.isPresent()) {
			return opt.get();
		} else {
			throw new ProdutoNotFoundException("Produto com id: " +id+ "não encontrado");
		}	
    }
     
   public void apagarProduto (Long id) throws ProdutoNotFoundException{
    Produtos produtos = buscarProdutosPorId(id);
    produtosRepositorio.delete(produtos);
   }

   public Produtos editarProduto (Produtos produtos){
    return produtosRepositorio.save(produtos);
 }

 public List<Produtos> buscarTodosProdutosPorModelo(String modelo){
    return produtosRepositorio.findByModeloContainingIgnoreCase(modelo);

}
    
}