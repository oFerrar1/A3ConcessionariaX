package com.projetoA3.Versao_Final_Projeto_.A3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VersaoFinalProjetoA3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
